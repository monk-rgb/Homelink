from flask import Flask, render_template, request, redirect, url_for, session, jsonify, flash, abort, send_file
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from uuid import uuid4
from functools import wraps
from pathlib import Path
from io import BytesIO
from hashlib import sha256
from dotenv import load_dotenv
import sqlite3, os, json, re, math, hmac, urllib.parse, urllib.request, mimetypes
from datetime import datetime, timezone, timedelta
from typing import Any
from PIL import Image, ImageOps
import numpy as np
import jwt

BASE=Path(__file__).resolve().parent
load_dotenv(BASE/'.env')
MAX_IMAGE_BYTES=8*1024*1024
MAX_IMAGE_COUNT=8
ALLOWED_IMAGE_MIMES={'image/jpeg','image/png','image/webp','image/gif'}
ALLOWED_IMAGE_EXTENSIONS={'jpg','jpeg','png','webp','gif'}
PHASH_SIZE=32
PHASH_BITS=8
PHASH_DISTANCE_THRESHOLD=int(os.getenv('IMAGE_PHASH_DISTANCE_THRESHOLD', '8'))
REVERSE_IMAGE_MIN_SCORE=float(os.getenv('REVERSE_IMAGE_MIN_SCORE', '0.80'))
Image.MAX_IMAGE_PIXELS=25_000_000
ANALYSIS_DEFAULTS={
    'property_type': None, 'floors_estimated': None, 'condition': 'unknown',
    'finishing_quality': 'unknown', 'construction_quality': 'unknown',
    'roof_condition': 'unknown', 'wall_condition': 'unknown',
    'flooring_quality': 'unknown', 'kitchen_quality': 'unknown',
    'bathroom_quality': 'unknown', 'parking_spaces_visible': None,
    'amenities': [], 'overall_property_condition': 'unknown',
    'visual_quality_score': None, 'analysis_confidence': 0.0
}
import pandas as pd
import joblib

try:
    from openai import OpenAI
except Exception:
    OpenAI = None

app=Flask(__name__)
app.secret_key=os.getenv('FLASK_SECRET_KEY','change-this-in-production')

# --- Admin authentication configuration -------------------------------------
# Admins authenticate once at a public login endpoint. On success the server
# issues a cryptographically signed JWT delivered as an HttpOnly cookie, so the
# browser attaches it automatically on every later /Admin/* request.
ADMIN_JWT_SECRET=os.getenv('ADMIN_JWT_SECRET') or app.secret_key
ADMIN_JWT_ALGORITHM='HS256'
ADMIN_JWT_TTL_SECONDS=int(os.getenv('ADMIN_JWT_TTL_SECONDS','28800'))
ADMIN_COOKIE_NAME='admin_token'
# Secure cookies require HTTPS. Enable ADMIN_COOKIE_SECURE=1 in production.
ADMIN_COOKIE_SECURE=os.getenv('ADMIN_COOKIE_SECURE','0').lower() in ('1','true','yes','on')
ADMIN_EMAIL=os.getenv('ADMIN_EMAIL','admin@estimate.ng').strip().lower()
PAYSTACK_SECRET_KEY=os.getenv('PAYSTACK_SECRET_KEY','').strip()
PAYSTACK_CALLBACK_BASE_URL=os.getenv('PAYSTACK_CALLBACK_BASE_URL','').rstrip('/')
PAYSTACK_RELEASE_CRON_SECRET=os.getenv('PAYSTACK_RELEASE_CRON_SECRET','').strip()
DB=BASE/'estimate.db'
UPLOADS=BASE/'static'/'uploads'
VERIFICATION_UPLOADS=BASE/'verification_uploads'
UPLOADS.mkdir(parents=True, exist_ok=True)
VERIFICATION_UPLOADS.mkdir(parents=True, exist_ok=True)
MODEL=joblib.load(BASE/'model.joblib')
DATA=pd.read_csv(BASE/'data.csv')
try:
    METRICS=json.loads((BASE/'metrics.json').read_text(encoding='utf-8'))
except (OSError,ValueError):
    METRICS={}
MODEL_CONFIDENCE=float(METRICS.get('r2',0))*100

DOCUMENT_TEMPLATES=[
    ('rent_notice','Rent Notice','RENT NOTICE\\n\\nDear Tenant,\\n\\nThis notice concerns the rent for {{details}}. Please review your tenancy records and make the required payment by the agreed due date.\\n\\nThank you,\\nESTIMATE Property Management'),
    ('listing','Property Listing','PROPERTY LISTING\\n\\nPresenting {{details}} — a well-positioned opportunity for discerning buyers or tenants. Contact the property manager for pricing, inspection and documentation.'),
    ('followup','Client Follow-up','FOLLOW-UP MESSAGE\\n\\nHello, I am following up regarding {{details}}. Please let me know a convenient time to continue the conversation or schedule an inspection.\\n\\nBest regards,\\nESTIMATE Property Management'),
    ('management_agreement','Property Management Agreement','PROPERTY MANAGEMENT AGREEMENT\\n\\nParties: [Owner] and ESTIMATE Property Management\\nProperty: {{details}}\\n\\nScope, fees, owner responsibilities and manager responsibilities: [Complete details].\\nHave a qualified professional review before signing.'),
    ('lease_agreement','Residential or Commercial Lease Agreement','LEASE AGREEMENT\\n\\nProperty: {{details}}\\n\\nInclude rent, duration, permitted use, maintenance, utilities, default and termination terms. Have a qualified professional review before signing.'),
    ('rental_application','Rental Application Form','RENTAL APPLICATION FORM\\n\\nProperty / applicant details: {{details}}\\n\\nInclude employment, income, references, rental history and lawful screening consent.'),
    ('rent_ledger','Rent Ledger','RENT LEDGER\\n\\nTenant/property: {{details}}\\n\\nDate | Description | Due | Paid | Balance | Reference\\nKeep entries chronological with supporting records.'),
    ('rent_receipt','Rent Receipt','RENT RECEIPT\\n\\nReceived from: [Tenant]\\nAmount: [Amount]\\nFor: {{details}}\\nPayment method: [Cash/Transfer/Check] | Date: [Date]\\nCheck against the payment record.'),
    ('eviction_notice','Notice to Quit / Eviction Notice','NOTICE TO QUIT / EVICTION NOTICE\\n\\nTenant/property: {{details}}\\n\\nState the breach, required action and applicable dates only after qualified local legal review. This draft is not legal advice.')
]
STATES=sorted(DATA['State'].dropna().unique().tolist())
PROPERTY_TYPES=['Detached Duplex','Terraced Duplex','Semi-Detached Duplex','Bungalow','Flat','Mansion','Block of Flats','Penthouse','Land']
CITIES=sorted(DATA['City'].dropna().unique().tolist())


def db():
    c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; return c

def init_db():
    c=db()
    # Admin accounts live in their own table so the public users table (which is
    # self-service signup) can never be used to mint an admin identity.
    c.execute('''CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT,email TEXT UNIQUE NOT NULL,password TEXT NOT NULL,role TEXT NOT NULL,created_at TEXT DEFAULT CURRENT_TIMESTAMP,username TEXT,phone TEXT,is_verified INTEGER DEFAULT 0,is_blocked INTEGER DEFAULT 0,blocked_at TEXT,block_reason TEXT)''')
    c.execute('''CREATE TABLE IF NOT EXISTS properties(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER,name TEXT,location TEXT,price REAL,status TEXT,thumb TEXT DEFAULT 'house',photo TEXT,published_to_propkonet INTEGER DEFAULT 0,beds INTEGER DEFAULT 3,baths INTEGER DEFAULT 3,sqft INTEGER DEFAULT 1800,property_type TEXT DEFAULT 'Detached Duplex',buyable INTEGER DEFAULT 1,ai_price REAL DEFAULT 0,listing_type TEXT DEFAULT 'sale',created_at TEXT DEFAULT CURRENT_TIMESTAMP)''')
    c.execute('''CREATE TABLE IF NOT EXISTS property_photos(id INTEGER PRIMARY KEY AUTOINCREMENT,property_id INTEGER NOT NULL,filename TEXT NOT NULL,created_at TEXT DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY(property_id) REFERENCES properties(id) ON DELETE CASCADE)''')
    c.execute('''CREATE TABLE IF NOT EXISTS image_fingerprints(id INTEGER PRIMARY KEY AUTOINCREMENT,property_id INTEGER,property_photo_id INTEGER,user_id INTEGER NOT NULL,filename TEXT NOT NULL,sha256 TEXT NOT NULL,phash TEXT NOT NULL,width INTEGER,height INTEGER,created_at TEXT DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY(property_id) REFERENCES properties(id) ON DELETE CASCADE,FOREIGN KEY(property_photo_id) REFERENCES property_photos(id) ON DELETE CASCADE,FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE)''')
    c.execute('''CREATE TABLE IF NOT EXISTS fraud_reports(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER NOT NULL,property_id INTEGER,filename TEXT,reason TEXT NOT NULL,match_type TEXT NOT NULL,match_source TEXT,match_reference TEXT,match_score REAL,status TEXT DEFAULT 'pending',created_at TEXT DEFAULT CURRENT_TIMESTAMP,reviewed_at TEXT,FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,FOREIGN KEY(property_id) REFERENCES properties(id) ON DELETE SET NULL)''')
    c.execute('''CREATE INDEX IF NOT EXISTS idx_image_fingerprints_phash ON image_fingerprints(phash)''')
    c.execute('''CREATE INDEX IF NOT EXISTS idx_fraud_reports_status ON fraud_reports(status,created_at)''')
    c.execute('''CREATE TABLE IF NOT EXISTS tasks(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER,title TEXT,due TEXT,done INTEGER DEFAULT 0)''')
    c.execute('''CREATE TABLE IF NOT EXISTS login_logs(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER,email TEXT NOT NULL,role TEXT NOT NULL,ip_address TEXT,logged_in_at TEXT DEFAULT CURRENT_TIMESTAMP)''')
    c.execute('''CREATE TABLE IF NOT EXISTS document_templates(id INTEGER PRIMARY KEY AUTOINCREMENT,task TEXT UNIQUE NOT NULL,title TEXT NOT NULL,body TEXT NOT NULL)''')
    c.execute('''CREATE TABLE IF NOT EXISTS verification_requests(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER NOT NULL,email TEXT NOT NULL,username TEXT NOT NULL,phone TEXT NOT NULL,status TEXT DEFAULT 'pending',business_address TEXT,nin_number TEXT,cac_number TEXT,face_photo TEXT,nin_photo TEXT,cac_photo TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP,updated_at TEXT DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE)''')
    c.execute('''CREATE TABLE IF NOT EXISTS property_purchases(id INTEGER PRIMARY KEY AUTOINCREMENT,property_id INTEGER,buyer_name TEXT NOT NULL,buyer_email TEXT NOT NULL,buyer_phone TEXT NOT NULL,offer_price REAL,message TEXT,status TEXT DEFAULT 'pending',created_at TEXT DEFAULT CURRENT_TIMESTAMP)''')
    c.execute('''CREATE TABLE IF NOT EXISTS property_transactions(
        id INTEGER PRIMARY KEY AUTOINCREMENT, property_id INTEGER NOT NULL, seller_id INTEGER NOT NULL,
        buyer_name TEXT NOT NULL, buyer_email TEXT NOT NULL, buyer_phone TEXT, amount_kobo INTEGER NOT NULL,
        reference TEXT UNIQUE NOT NULL, buyer_token TEXT UNIQUE NOT NULL, status TEXT NOT NULL DEFAULT 'checkout_created',
        paid_at TEXT, documents_ready_at TEXT, buyer_confirmed_at TEXT, release_at TEXT,
        transfer_reference TEXT UNIQUE, transfer_status TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(property_id) REFERENCES properties(id), FOREIGN KEY(seller_id) REFERENCES users(id)
    )''')
    c.execute('CREATE INDEX IF NOT EXISTS idx_property_transactions_release ON property_transactions(status, release_at)')
    c.execute('''CREATE TABLE IF NOT EXISTS admin_users(id INTEGER PRIMARY KEY AUTOINCREMENT,email TEXT UNIQUE NOT NULL,password TEXT NOT NULL,role TEXT NOT NULL DEFAULT 'admin',mfa_secret TEXT,is_active INTEGER DEFAULT 1,created_at TEXT DEFAULT CURRENT_TIMESTAMP,last_login_at TEXT)''')
    c.execute('''CREATE TABLE IF NOT EXISTS admin_login_logs(id INTEGER PRIMARY KEY AUTOINCREMENT,admin_id INTEGER,email TEXT NOT NULL,ip_address TEXT,user_agent TEXT,success INTEGER DEFAULT 1,created_at TEXT DEFAULT CURRENT_TIMESTAMP)''')
    for task,title,body in DOCUMENT_TEMPLATES:
        c.execute('INSERT OR IGNORE INTO document_templates(task,title,body) VALUES(?,?,?)',(task,title,body))
    # Safe migrations for existing databases
    for col in ['username TEXT', 'phone TEXT', 'is_verified INTEGER DEFAULT 0', 'is_blocked INTEGER DEFAULT 0', 'blocked_at TEXT', 'block_reason TEXT']:
        try: c.execute(f'ALTER TABLE users ADD COLUMN {col}')
        except sqlite3.OperationalError: pass
    try: c.execute('ALTER TABLE users ADD COLUMN paystack_recipient_code TEXT')
    except sqlite3.OperationalError: pass
    for col in [
        'photo TEXT',
        'published_to_propkonet INTEGER DEFAULT 0',
        'beds INTEGER DEFAULT 3',
        'baths INTEGER DEFAULT 3',
        'sqft INTEGER DEFAULT 1800',
        'property_type TEXT DEFAULT "Detached Duplex"',
        'buyable INTEGER DEFAULT 1',
        'ai_price REAL DEFAULT 0',
        'listing_type TEXT DEFAULT "sale"'
    ]:
        try: c.execute(f'ALTER TABLE properties ADD COLUMN {col}')
        except sqlite3.OperationalError: pass
    for col in [
        'business_address TEXT',
        'nin_number TEXT',
        'cac_number TEXT',
        'face_photo TEXT',
        'nin_photo TEXT',
        'cac_photo TEXT'
    ]:
        try: c.execute(f'ALTER TABLE verification_requests ADD COLUMN {col}')
        except sqlite3.OperationalError: pass
    c.commit(); c.close()

def bootstrap_admin():
    # Create/refresh a bootstrap admin from the environment so a fresh install
    # has at least one admin account to log in with at /api/admin/login.
    email=ADMIN_EMAIL
    password=os.getenv('ADMIN_PASSWORD')
    if not email or not password:
        return
    c=db()
    existing=c.execute('SELECT id FROM admin_users WHERE email=?',(email,)).fetchone()
    if existing is None:
        c.execute("INSERT INTO admin_users(email,password,role,is_active) VALUES(?,?,'admin',1)",(email,generate_password_hash(password)))
        c.commit()
    c.close()

init_db()
bootstrap_admin()

def _load_image(raw):
    try:
        image=Image.open(BytesIO(raw))
        image.load()
        return ImageOps.exif_transpose(image).convert('RGB')
    except (OSError, ValueError, Image.DecompressionBombError):
        return None

def _dct_matrix(size):
    indices=np.arange(size, dtype=np.float32)
    return np.cos(np.pi/size*(indices[:,None]+0.5)*indices[None,:])

def _perceptual_hash(image):
    gray=image.convert('L').resize((PHASH_SIZE,PHASH_SIZE),Image.Resampling.LANCZOS)
    pixels=np.asarray(gray, dtype=np.float32)
    matrix=_dct_matrix(PHASH_SIZE)
    coefficients=matrix.T @ pixels @ matrix
    low_frequency=coefficients[:PHASH_BITS,:PHASH_BITS]
    comparison=low_frequency.flatten()[1:]
    median=float(np.median(comparison))
    value=0
    for bit in (comparison > median):
        value=(value<<1)|int(bit)
    return f'{value:016x}'

def fingerprint_image(raw):
    image=_load_image(raw)
    if image is None:
        return None
    return {
        'sha256': sha256(raw).hexdigest(),
        'phash': _perceptual_hash(image),
        'width': image.width,
        'height': image.height
    }

def hamming_distance(first, second):
    try:
        return (int(first,16)^int(second,16)).bit_count()
    except (TypeError, ValueError):
        return 64

def reverse_image_matches(raw):
    endpoint=os.getenv('REVERSE_IMAGE_API_URL','').strip()
    if not endpoint:
        return [], 'Reverse-image search is not configured.'
    boundary='----EstiMateImageGuardrail'+uuid4().hex
    lines=[]
    lines.append(f'--{boundary}')
    lines.append('Content-Disposition: form-data; name="image"; filename="image.bin"')
    lines.append('Content-Type: application/octet-stream')
    lines.append('')
    body_parts=[('\r\n'.join(lines)).encode('utf-8'), raw, f'\r\n--{boundary}--\r\n'.encode('utf-8')]
    body=b''.join(body_parts)
    headers={'Content-Type':f'multipart/form-data; boundary={boundary}','Accept':'application/json','User-Agent':'EstiMate Image Guardrail/1.0'}
    api_key=os.getenv('REVERSE_IMAGE_API_KEY','').strip()
    if api_key:
        headers['Authorization']='Bearer '+api_key
    try:
        api_request=urllib.request.Request(endpoint, data=body, headers=headers, method='POST')
        with urllib.request.urlopen(api_request, timeout=15) as response:
            payload=json.load(response)
        if isinstance(payload, dict):
            items=payload.get('matches') or payload.get('results') or []
        elif isinstance(payload, list):
            items=payload
        else:
            items=[]
        matches=[]
        for item in items:
            if not isinstance(item, dict):
                continue
            url=item.get('url') or item.get('source_url') or item.get('link')
            score=item.get('score') or item.get('similarity') or item.get('confidence') or 0
            try:
                score=float(score)
            except (TypeError, ValueError):
                score=0
            if url and score >= REVERSE_IMAGE_MIN_SCORE:
                matches.append({'url':str(url),'score':score,'title':str(item.get('title') or item.get('source') or url)})
        return matches, None
    except Exception:
        app.logger.exception('Reverse-image search failed')
        return [], 'Reverse-image search is temporarily unavailable.'

def find_database_image_match(fingerprint, exclude_property_id=None):
    c=db()
    rows=c.execute('SELECT * FROM image_fingerprints ORDER BY id').fetchall()
    c.close()
    best=None
    for row in rows:
        if exclude_property_id is not None and row['property_id']==exclude_property_id:
            continue
        if row['sha256']==fingerprint['sha256']:
            candidate={'row':row,'match_type':'exact_duplicate','score':1.0}
            best=candidate
            break
        distance=hamming_distance(fingerprint['phash'], row['phash'])
        if distance <= PHASH_DISTANCE_THRESHOLD:
            candidate={'row':row,'match_type':'perceptual_duplicate','score':1-distance/64,'distance':distance}
            if best is None or candidate['score'] > best['score']:
                best=candidate
    return best

def record_fraud(user_id, property_id, filename, reason, match_type, match_source, match_reference, match_score):
    c=db()
    cur=c.execute('''INSERT INTO fraud_reports(user_id,property_id,filename,reason,match_type,match_source,match_reference,match_score) VALUES(?,?,?,?,?,?,?,?)''',(user_id,property_id,filename,reason,match_type,match_source,match_reference,match_score))
    c.commit()
    report_id=cur.lastrowid
    c.close()
    return report_id

def scan_property_images(files, user_id, exclude_property_id=None):
    prepared=[]
    seen_hashes=set()
    for photo in files:
        if not photo or not photo.filename:
            continue
        ext=photo.filename.rsplit('.',1)[-1].lower() if '.' in photo.filename else ''
        if ext not in ALLOWED_IMAGE_EXTENSIONS:
            return None, {'error':'Upload JPG, PNG, WEBP or GIF images only.'}
        raw=photo.read()
        if not raw or len(raw)>MAX_IMAGE_BYTES:
            return None, {'error':'Each image must be larger than 0 bytes and no more than 8 MB.'}
        fingerprint=fingerprint_image(raw)
        if fingerprint is None:
            return None, {'error':'One or more uploads are not valid images.'}
        if fingerprint['sha256'] in seen_hashes:
            return None, {'error':'The same image cannot be uploaded more than once in one submission.'}
        seen_hashes.add(fingerprint['sha256'])
        database_match=find_database_image_match(fingerprint, exclude_property_id)
        if database_match:
            row=database_match['row']
            report_id=record_fraud(user_id, exclude_property_id, photo.filename, 'Image matches an existing image in the PropkoNet database.', database_match['match_type'], 'database', row['filename'], database_match['score'])
            return None, {'error':'Image guardrail flagged this submission for fraud review.','fraud':True,'fraud_report_id':report_id,'match_type':database_match['match_type'],'matched_image':row['filename'],'match_score':database_match['score']}
        external_matches, external_message=reverse_image_matches(raw)
        if external_matches:
            match=external_matches[0]
            report_id=record_fraud(user_id, exclude_property_id, photo.filename, 'Image matches a publicly indexed image from another site.', 'reverse_image_match', 'external', match['url'], match['score'])
            return None, {'error':'Image guardrail flagged this submission for fraud review.','fraud':True,'fraud_report_id':report_id,'match_type':'reverse_image_match','matched_image':match['url'],'match_score':match['score']}
        if external_message:
            prepared.append({'photo':photo,'raw':raw,'filename':photo.filename,'ext':ext,'fingerprint':fingerprint,'reverse_image_message':external_message})
        else:
            prepared.append({'photo':photo,'raw':raw,'filename':photo.filename,'ext':ext,'fingerprint':fingerprint})
    return prepared, None

def scan_saved_property_images(property_id, user_id):
    c=db()
    rows=c.execute('SELECT id,filename FROM property_photos WHERE property_id=? ORDER BY id',(property_id,)).fetchall()
    c.close()
    seen=set()
    for row in rows:
        path=UPLOADS/row['filename']
        if not path.exists():
            continue
        try:
            raw=path.read_bytes()
        except OSError:
            continue
        fingerprint=fingerprint_image(raw)
        if fingerprint is None or fingerprint['sha256'] in seen:
            continue
        seen.add(fingerprint['sha256'])
        database_match=find_database_image_match(fingerprint, exclude_property_id=property_id)
        if database_match:
            row_match=database_match['row']
            report_id=record_fraud(user_id, property_id, row['filename'], 'Published image matches an existing image in the PropkoNet database.', database_match['match_type'], 'database', row_match['filename'], database_match['score'])
            return {'error':'Image guardrail flagged this property for fraud review.','fraud':True,'fraud_report_id':report_id,'match_type':database_match['match_type'],'matched_image':row_match['filename'],'match_score':database_match['score']}
        external_matches, external_message=reverse_image_matches(raw)
        if external_matches:
            match=external_matches[0]
            report_id=record_fraud(user_id, property_id, row['filename'], 'Published image matches a publicly indexed image from another site.', 'reverse_image_match', 'external', match['url'], match['score'])
            return {'error':'Image guardrail flagged this property for fraud review.','fraud':True,'fraud_report_id':report_id,'match_type':'reverse_image_match','matched_image':match['url'],'match_score':match['score']}
    return None

def persist_prepared_images(c, prepared, property_id):
    names=[]
    for item in prepared:
        name=f'{uuid4().hex}.{item["ext"]}'
        (UPLOADS/name).write_bytes(item['raw'])
        names.append(name)
        photo_cur=c.execute('INSERT INTO property_photos(property_id,filename) VALUES(?,?)',(property_id,name))
        fingerprint=item['fingerprint']
        c.execute('''INSERT INTO image_fingerprints(property_id,property_photo_id,user_id,filename,sha256,phash,width,height) VALUES(?,?,?,?,?,?,?,?)''',(property_id,photo_cur.lastrowid,session['user_id'],name,fingerprint['sha256'],fingerprint['phash'],fingerprint['width'],fingerprint['height']))
    return names

def backfill_image_fingerprints():
    c=db()
    rows=c.execute('SELECT pp.id AS photo_id, pp.filename, p.id AS property_id, p.user_id FROM property_photos pp JOIN properties p ON p.id=pp.property_id').fetchall()
    for row in rows:
        exists=c.execute('SELECT id FROM image_fingerprints WHERE property_photo_id=?',(row['photo_id'],)).fetchone()
        if exists:
            continue
        path=UPLOADS/row['filename']
        if not path.exists():
            continue
        try:
            raw=path.read_bytes()
        except OSError:
            continue
        fingerprint=fingerprint_image(raw)
        if fingerprint is None:
            continue
        c.execute('''INSERT INTO image_fingerprints(property_id,property_photo_id,user_id,filename,sha256,phash,width,height) VALUES(?,?,?,?,?,?,?,?)''',(row['property_id'],row['photo_id'],row['user_id'],row['filename'],fingerprint['sha256'],fingerprint['phash'],fingerprint['width'],fingerprint['height']))
    c.commit(); c.close()

backfill_image_fingerprints()

def verification_document_path(filename):
    if not filename or Path(filename).name != filename:
        return None
    path=VERIFICATION_UPLOADS/filename
    return path if path.exists() else None

def validate_verification_upload(storage, field):
    if not storage or not storage.filename:
        return None, f'{field} image is required.'
    ext=storage.filename.rsplit('.',1)[-1].lower() if '.' in storage.filename else ''
    if ext not in ALLOWED_IMAGE_EXTENSIONS:
        return None, f'{field} must be a JPG, PNG, WEBP or GIF image.'
    raw=storage.read()
    if not raw or len(raw)>MAX_IMAGE_BYTES:
        return None, f'{field} must be larger than 0 bytes and no more than 8 MB.'
    if fingerprint_image(raw) is None:
        return None, f'{field} is not a valid image.'
    return raw, None

def save_verification_upload(raw, ext):
    filename=f'{uuid4().hex}.{ext}'
    (VERIFICATION_UPLOADS/filename).write_bytes(raw)
    return filename

def cleanup_verification_uploads(filenames):
    for filename in filenames or []:
        if not filename:
            continue
        try: (VERIFICATION_UPLOADS/filename).unlink(missing_ok=True)
        except OSError: pass

def login_required(f):
    @wraps(f)
    def wrap(*a,**kw):
        if not session.get('user_id'): return redirect(url_for('login'))
        return f(*a,**kw)
    return wrap

def owner_required(f):
    @wraps(f)
    def wrap(*a,**kw):
        if not session.get('user_id'): return redirect(url_for('login'))
        if session.get('role')!='owner': return redirect(url_for('welcome'))
        c=db(); user=c.execute('SELECT is_blocked FROM users WHERE id=?',(session['user_id'],)).fetchone(); c.close()
        if user and user['is_blocked']:
            session.clear(); flash('This account has been blocked. Contact support for assistance.','error'); return redirect(url_for('login'))
        return f(*a,**kw)
    return wrap

# --- Paystack property-purchase workflow -----------------------------------
# Funds are collected by the platform, never by the browser. Paystack's webhook
# and a server-side verification are the source of truth for a successful sale.
def paystack_request(path, method='GET', payload=None):
    if not PAYSTACK_SECRET_KEY:
        raise RuntimeError('Paystack is not configured. Add PAYSTACK_SECRET_KEY to .env.')
    data=json.dumps(payload).encode('utf-8') if payload is not None else None
    req=urllib.request.Request('https://api.paystack.co'+path, data=data, method=method)
    req.add_header('Authorization', f'Bearer {PAYSTACK_SECRET_KEY}')
    req.add_header('Content-Type', 'application/json')
    try:
        with urllib.request.urlopen(req, timeout=20) as response:
            result=json.loads(response.read().decode('utf-8'))
    except urllib.error.HTTPError as exc:
        detail=exc.read().decode('utf-8', 'replace')
        raise RuntimeError(f'Paystack request failed: {detail[:300]}') from exc
    except (urllib.error.URLError, ValueError) as exc:
        raise RuntimeError('Could not reach Paystack. Please try again.') from exc
    if not result.get('status'):
        raise RuntimeError(result.get('message') or 'Paystack rejected the request.')
    return result.get('data') or {}

def payment_callback_url(reference, buyer_token):
    base=PAYSTACK_CALLBACK_BASE_URL or request.url_root.rstrip('/')
    return f'{base}{url_for("payment_callback", reference=reference, token=buyer_token)}'

def add_seller_task(c, seller_id, title, due='Property sale'):
    c.execute('INSERT INTO tasks(user_id,title,due,done) VALUES(?,?,?,0)', (seller_id, title[:150], due))

def mark_transaction_paid(reference):
    """Verify the charge with Paystack before changing a transaction state."""
    c=db(); transaction=c.execute('SELECT * FROM property_transactions WHERE reference=?',(reference,)).fetchone()
    if not transaction:
        c.close(); return False
    if transaction['status'] not in ('checkout_created', 'payment_pending'):
        c.close(); return transaction['status'] in ('paid','documents_ready','awaiting_release','released')
    c.close()
    data=paystack_request('/transaction/verify/'+urllib.parse.quote(reference, safe=''))
    if data.get('status') != 'success' or str(data.get('reference')) != reference or int(data.get('amount') or 0) != transaction['amount_kobo']:
        return False
    c=db()
    current=c.execute('SELECT * FROM property_transactions WHERE reference=?',(reference,)).fetchone()
    if current and current['status'] in ('checkout_created','payment_pending'):
        c.execute("UPDATE property_transactions SET status='paid', paid_at=CURRENT_TIMESTAMP WHERE id=?",(current['id'],))
        property_row=c.execute('SELECT name FROM properties WHERE id=?',(current['property_id'],)).fetchone()
        property_name=property_row['name'] if property_row else 'your property'
        buyer_contact=', '.join([part for part in [current['buyer_name'], current['buyer_phone']] if part])
        add_seller_task(
            c, current['seller_id'],
            f"Dear stakeholder, {buyer_contact} has paid for the {property_name}, do well to hand over the necessary documents, your account will be credited 24hrs after the customers Confirmation",
            'Payment received')
        c.commit()
    c.close(); return True

def release_due_transactions():
    """Initiate due payouts. Call this from a trusted hourly scheduler in production."""
    if not PAYSTACK_SECRET_KEY:
        return []
    c=db(); due=c.execute("""SELECT t.*,u.paystack_recipient_code,p.name AS property_name
        FROM property_transactions t JOIN users u ON u.id=t.seller_id
        JOIN properties p ON p.id=t.property_id
        WHERE t.status='awaiting_release' AND t.release_at <= CURRENT_TIMESTAMP""").fetchall(); c.close()
    results=[]
    for transaction in due:
        recipient=transaction['paystack_recipient_code']
        if not recipient:
            c=db(); c.execute("UPDATE property_transactions SET transfer_status='seller bank details required' WHERE id=?",(transaction['id'],))
            add_seller_task(c, transaction['seller_id'], f'Payout blocked for {transaction["property_name"]}: add your Paystack recipient code to receive the sale funds.', 'Urgent')
            c.commit(); c.close(); results.append({'reference':transaction['reference'],'released':False}); continue
        transfer_reference='PAYOUT-'+uuid4().hex
        try:
            transfer=paystack_request('/transfer','POST',{
                'source':'balance','amount':transaction['amount_kobo'],'recipient':recipient,
                'reason':f'Property sale payout: {transaction["property_name"]}','reference':transfer_reference
            })
            transfer_status=transfer.get('status') or 'pending'
            c=db(); c.execute("UPDATE property_transactions SET status='released',transfer_reference=?,transfer_status=? WHERE id=? AND status='awaiting_release'",(transfer_reference,transfer_status,transaction['id']))
            add_seller_task(c, transaction['seller_id'], f'Payout initiated for {transaction["property_name"]}. Paystack transfer reference: {transfer_reference}.', 'Payment')
            c.commit(); c.close(); results.append({'reference':transaction['reference'],'released':True})
        except RuntimeError as exc:
            c=db(); c.execute('UPDATE property_transactions SET transfer_status=? WHERE id=?',(str(exc)[:250],transaction['id'])); c.commit(); c.close(); results.append({'reference':transaction['reference'],'released':False})
    return results

# --- Admin identity, tokens and authorization middleware --------------------

def issue_admin_token(admin_id, email, role='admin'):
    # Create a cryptographically signed JWT carrying the admin identity.
    now=datetime.now(timezone.utc)
    payload={
        'sub': str(admin_id),
        'userId': int(admin_id),
        'email': email,
        'role': role,
        'iat': int(now.timestamp()),
        'exp': int((now + timedelta(seconds=ADMIN_JWT_TTL_SECONDS)).timestamp()),
    }
    return jwt.encode(payload, ADMIN_JWT_SECRET, algorithm=ADMIN_JWT_ALGORITHM)

def decode_admin_token(token):
    # Verify signature/expiry and return the claims, or None when untrusted.
    if not token:
        return None
    try:
        return jwt.decode(token, ADMIN_JWT_SECRET, algorithms=[ADMIN_JWT_ALGORITHM])
    except jwt.PyJWTError:
        return None

def current_admin():
    # Return the verified admin claims from the request cookie, or None.
    # Prefers the Authorization: Bearer header, then falls back to the HttpOnly
    # admin cookie that the browser attaches automatically on /Admin/* requests.
    token=None
    auth_header=request.headers.get('Authorization','')
    if auth_header.lower().startswith('bearer '):
        token=auth_header[7:].strip()
    if not token:
        token=request.cookies.get(ADMIN_COOKIE_NAME)
    claims=decode_admin_token(token)
    if not claims:
        return None
    return claims if claims.get('role')=='admin' else None

def _wants_json():
    return request.path.startswith('/api/') or request.accept_mimetypes.best=='application/json'

def _admin_denied(status, message):
    # Halt a request that failed the admin role check with 401 or 403.
    # JSON clients get a JSON body; browsers get the same status code with a
    # readable page instead of a redirect, so the failure is never masked.
    if _wants_json():
        return jsonify({'error':message}), status
    return render_template('admin_denied.html',status=status,message=message), status

def admin_required(f):
    # Authorization middleware for the protected /Admin/* routes.
    # Decodes the admin token and checks the role claim. Admins pass straight
    # through; a customer/missing/bogus token is halted with 401 (no credential)
    # or 403 (authenticated but not an admin).
    @wraps(f)
    def wrap(*a,**kw):
        token=request.cookies.get(ADMIN_COOKIE_NAME) or request.headers.get('Authorization','').removeprefix('Bearer ').strip()
        if not token:
            return _admin_denied(401,'Authentication required. Please log in as an admin.')
        claims=decode_admin_token(token)
        if not claims:
            return _admin_denied(401,'Your admin session is invalid or has expired. Please log in again.')
        if claims.get('role')!='admin':
            return _admin_denied(403,'You do not have permission to access this resource.')
        request.admin=claims
        return f(*a,**kw)
    return wrap

def naira(v): return '₦{:,.0f}'.format(float(v))

def million_naira(v):
    value=float(v) / 1_000_000
    if not value:
        return '₦0M'
    formatted=f'{value:,.2f}'.rstrip('0').rstrip('.')
    return f'₦{formatted}M'

def _bounded_number(value, low, high, default=None):
    try:
        value=float(value)
        return max(low,min(high,value))
    except (TypeError,ValueError):
        return default

def normalize_visual_analysis(data):
    result=ANALYSIS_DEFAULTS.copy()
    if isinstance(data,dict): result.update({k:v for k,v in data.items() if k in result})
    result['amenities']=[str(x)[:80] for x in result.get('amenities',[])[:12]] if isinstance(result.get('amenities'),list) else []
    result['floors_estimated']=_bounded_number(result.get('floors_estimated'),1,20)
    if result['floors_estimated'] is not None: result['floors_estimated']=int(result['floors_estimated'])
    result['parking_spaces_visible']=_bounded_number(result.get('parking_spaces_visible'),0,100)
    if result['parking_spaces_visible'] is not None: result['parking_spaces_visible']=int(result['parking_spaces_visible'])
    result['visual_quality_score']=_bounded_number(result.get('visual_quality_score'),0,100)
    if result['visual_quality_score'] is not None: result['visual_quality_score']=int(result['visual_quality_score'])
    result['analysis_confidence']=_bounded_number(result.get('analysis_confidence'),0,1,0)
    return result

def enforce_lagos_large_home_floor(price, bedrooms, *locations):
    try:
        is_large_home = int(bedrooms) >= 6
    except (TypeError, ValueError):
        is_large_home = False
    is_lagos = any('lagos' in str(location or '').lower() for location in locations)
    return max(float(price), 1_400_000_001) if is_large_home and is_lagos else float(price)

def predict_from_payload(payload):
    property_type=payload.get('property_type') or PROPERTY_TYPES[0]
    state=payload.get('state') or STATES[0]
    city=payload.get('town') or payload.get('city') or CITIES[0]
    row=pd.DataFrame([{'State':state,'City':city,'Property_Type':{'Terraced Duplex':'Terrace Duplex'}.get(property_type,property_type),
        'Bedrooms':max(1,int(payload.get('bedrooms',1))), 'Bathrooms':max(1,int(payload.get('bathrooms',1))),
        'Area_sqm':max(20,float(payload.get('land_size',payload.get('area',100)))),
        'Age_Years':max(0,float(payload.get('property_age',payload.get('age',0)))),
        'Parking_Spaces':max(0,int(payload.get('parking_spaces',payload.get('parking',0))))}])
    base_price=float(MODEL.predict(row)[0])
    base_price=enforce_lagos_large_home_floor(base_price, row.iloc[0]['Bedrooms'], state, city)
    visual=payload.get('visual_features') or {}
    score=_bounded_number(visual.get('visual_quality_score'),0,100)
    # The trained model remains the valuation authority; visual evidence only applies
    # a small, bounded presentation adjustment when a score was actually observed.
    visual_factor=1 + ((score-70)/1000 if score is not None else 0)
    price=base_price*max(.93,min(1.07,visual_factor))
    return price,row.iloc[0].to_dict(),visual

def openai_failure_message(exc, feature):
    code=getattr(exc,'code',None)
    body=getattr(exc,'body',None)
    if not code and isinstance(body,dict):
        code=(body.get('error') or {}).get('code')
    text=str(exc).lower()
    if code=='insufficient_quota' or 'quota' in text or 'credits remaining' in text:
        return f'OpenAI {feature} is temporarily unavailable because the API account has no credits remaining. Add billing or credits, then try again.'
    if 'authentication' in text or 'api key' in text or '401' in text:
        return f'OpenAI {feature} is not authenticated. Replace the server OPENAI_API_KEY and restart the app.'
    return f'OpenAI {feature} failed. Check the server configuration and try again.'

def extract_listing_price(text):
    match=re.search(r'(?:₦|NGN)\s*([\d,]+(?:\.\d+)?)\s*(million|m|billion|bn)?',text,re.IGNORECASE)
    if not match: return None
    value=float(match.group(1).replace(',',''))
    unit=(match.group(2) or '').lower()
    if unit in {'million','m'}: value*=1_000_000
    if unit in {'billion','bn'}: value*=1_000_000_000
    return round(value) if value > 0 else None

def online_listing_matches(query):
    api_key=os.getenv('SERPAPI_KEY')
    if not api_key: return [], 'Online listing search is not configured. Add SERPAPI_KEY to enable price matches.'
    params=urllib.parse.urlencode({'engine':'google','q':query,'api_key':api_key,'num':8})
    try:
        search_request=urllib.request.Request('https://serpapi.com/search.json?'+params,headers={'User-Agent':'EstiMate Property Search/1.0'})
        with urllib.request.urlopen(search_request,timeout=12) as response:
            payload=json.load(response)
        matches=[]
        for item in payload.get('organic_results',[]):
            text=' '.join(str(item.get(key) or '') for key in ('title','snippet'))
            price=extract_listing_price(text)
            if price:
                matches.append({'site':str(item.get('source') or urllib.parse.urlparse(item.get('link','')).netloc),'title':str(item.get('title') or 'Online property listing'),'url':item.get('link',''),'price':price})
        return matches, ('No listing prices were found in the online results.' if not matches else None)
    except Exception:
        app.logger.exception('Online property listing search failed')
        return [], 'Online listing search is temporarily unavailable. Try again later.'

@app.context_processor
def ctx(): return {'logged':bool(session.get('user_id')),'role':session.get('role'),'user_email':session.get('email'),'naira':naira,'million_naira':million_naira}

@app.route('/')
def welcome(): return render_template('welcome.html')

@app.route('/signup',methods=['GET','POST'])
def signup():
    if request.method=='POST':
        email=request.form.get('email','').strip().lower(); username=request.form.get('username','').strip(); password=request.form.get('password',''); role=request.form.get('role','user')
        if not email or not username or not password: flash('Enter an email, username and password.','error'); return render_template('auth.html',mode='signup')
        c=db()
        try:
            c.execute('INSERT INTO users(email,username,password,role) VALUES(?,?,?,?)',(email,username,generate_password_hash(password),role)); c.commit()
        except sqlite3.IntegrityError:
            c.close(); flash('Account already exists. Please log in.','error'); return redirect(url_for('login'))
        c.close(); flash('Account created. You can now log in.','success'); return redirect(url_for('login'))
    return render_template('auth.html',mode='signup')

@app.route('/login',methods=['GET','POST'])
def login():
    if request.method=='POST':
        email=request.form.get('email','').strip().lower(); username=request.form.get('username','').strip(); password=request.form.get('password',''); role=request.form.get('role','user')
        c=db(); u=c.execute('SELECT * FROM users WHERE email=?',(email,)).fetchone(); c.close()
        if not u or not check_password_hash(u['password'],password): flash('Invalid email or password.','error'); return render_template('auth.html',mode='login')
        if u['is_blocked']:
            flash('This account has been blocked. Contact support for assistance.','error'); return render_template('auth.html',mode='login')
        if role != u['role']:
            flash('That account was created with a different account type. Choose the correct role.','error'); return render_template('auth.html',mode='login')
        c=db(); c.execute('INSERT INTO login_logs(user_id,email,role,ip_address) VALUES(?,?,?,?)',(u['id'],u['email'],u['role'],request.remote_addr)); c.commit(); c.close()
        session.update(user_id=u['id'],email=u['email'],role=u['role']); return redirect(url_for('property_manager' if u['role']=='owner' else 'welcome'))
    return render_template('auth.html',mode='login')

@app.route('/logout')
def logout(): session.clear(); return redirect(url_for('welcome'))

# --- Public admin login endpoint --------------------------------------------

def _admin_login_succeeds(email, password, mfa_code):
    # Verify credentials against the admin_users table. Returns the row or None.
    c=db()
    admin=c.execute('SELECT * FROM admin_users WHERE email=?',(email,)).fetchone()
    c.close()
    if not admin or not admin['is_active']:
        return None
    if not check_password_hash(admin['password'], password):
        return None
    # Optional second factor: enforced only when a secret is provisioned.
    secret=(admin['mfa_secret'] or '').strip()
    if secret:
        provided=str(mfa_code or '').strip()
        if not provided or not hmac.compare_digest(provided, secret):
            return None
    return admin

def _record_admin_login(admin_id, email, success):
    c=db()
    placeholders=','.join(['?']*5)
    c.execute('INSERT INTO admin_login_logs(admin_id,email,ip_address,user_agent,success) VALUES('+placeholders+')',
              (admin_id,email,request.remote_addr,request.headers.get('User-Agent','')[:255],1 if success else 0))
    if success:
        c.execute('UPDATE admin_users SET last_login_at=CURRENT_TIMESTAMP WHERE id=?',(admin_id,))
    c.commit(); c.close()

@app.post('/api/admin/login')
def admin_login_api():
    # Unprotected login endpoint: verifies the password hash, then issues a
    # signed JWT delivered as an HttpOnly (and, in production, Secure) cookie.
    data=request.get_json(silent=True) or request.form
    email=str(data.get('email','')).strip().lower()
    password=str(data.get('password',''))
    mfa_code=str(data.get('mfa_code') or data.get('mfa') or '')
    if not email or not password:
        return jsonify({'error':'Email and password are required.'}),400
    admin=_admin_login_succeeds(email,password,mfa_code)
    if not admin:
        _record_admin_login(None,email,False)
        return jsonify({'error':'Invalid admin credentials.'}),401
    token=issue_admin_token(admin['id'], admin['email'], admin['role'])
    _record_admin_login(admin['id'], admin['email'], True)
    response=jsonify({'ok':True,'role':admin['role'],'email':admin['email'],'expires_in':ADMIN_JWT_TTL_SECONDS})
    response.set_cookie(
        ADMIN_COOKIE_NAME, token,
        max_age=ADMIN_JWT_TTL_SECONDS,
        httponly=True, samesite='Lax', secure=ADMIN_COOKIE_SECURE, path='/',
    )
    return response
@app.route('/Admin', methods=['GET','POST'])
def admin():
    # Public dashboard entry point. Any visitor may load it, but it only renders
    # the protected dashboard for a request carrying a valid admin token.
    if not session.get('admin_authenticated') and current_admin():
        session['admin_authenticated']=True
    if not session.get('admin_authenticated'):
        error=session.pop('admin_login_error',None)
        return render_template('admin.html',authenticated=False,error=error)
    c=db()
    logs=c.execute('SELECT email,role,ip_address,logged_in_at FROM login_logs ORDER BY id DESC').fetchall()
    verifications=c.execute('SELECT * FROM verification_requests ORDER BY id DESC').fetchall()
    pending_verifications=[v for v in verifications if v['status']=='pending']
    pending_count=len(pending_verifications)
    fraud_reports=c.execute('''SELECT f.*,u.email,u.username,u.is_blocked,p.name AS property_name,p.location AS property_location FROM fraud_reports f JOIN users u ON u.id=f.user_id LEFT JOIN properties p ON p.id=f.property_id ORDER BY f.id DESC''').fetchall()
    pending_fraud_reports=[r for r in fraud_reports if r['status']=='pending']
    fraud_count=len(fraud_reports)
    c.close()
    return render_template('admin.html',authenticated=True,logs=logs,verifications=verifications,pending_verifications=pending_verifications,pending_count=pending_count,fraud_reports=fraud_reports,pending_fraud_reports=pending_fraud_reports,fraud_count=fraud_count)

@app.post('/Admin/verification/<int:req_id>/accept')
@admin_required
def admin_accept_verification(req_id):
    c=db()
    req=c.execute('SELECT * FROM verification_requests WHERE id=?', (req_id,)).fetchone()
    if not req:
        c.close(); flash('Verification request not found.', 'error'); return redirect(url_for('admin'))
    c.execute("UPDATE verification_requests SET status='approved', updated_at=CURRENT_TIMESTAMP WHERE id=?", (req_id,))
    c.execute("UPDATE users SET is_verified=1, username=?, phone=? WHERE id=?", (req['username'], req['phone'], req['user_id']))
    c.execute("INSERT INTO tasks(user_id,title,due,done) VALUES(?,?,'Immediate',0)", (req['user_id'], 'Seller verification approved. You can now publish properties directly to PropkoNet.'))
    c.commit(); c.close()
    flash(f"Verification accepted for {req['username']} ({req['email']}). This seller can now add properties to PropkoNet.", 'success')
    return redirect(url_for('admin'))

@app.post('/Admin/verification/<int:req_id>/reject')
@admin_required
def admin_reject_verification(req_id):
    c=db()
    req=c.execute('SELECT * FROM verification_requests WHERE id=?', (req_id,)).fetchone()
    if req:
        c.execute("UPDATE verification_requests SET status='rejected', updated_at=CURRENT_TIMESTAMP WHERE id=?", (req_id,))
        c.execute("UPDATE users SET is_verified=0 WHERE id=?", (req['user_id'],))
        c.commit()
        flash(f"Verification rejected for {req['username']}.", 'info')
    c.close()
    return redirect(url_for('admin'))

@app.get('/Admin/verification/<int:req_id>/review')
@admin_required
def admin_review_verification(req_id):
    c=db()
    req=c.execute('SELECT * FROM verification_requests WHERE id=?',(req_id,)).fetchone()
    c.close()
    if not req:
        flash('Verification request not found.','error'); return redirect(url_for('admin'))
    return render_template('verification_review.html',verification=req)

@app.get('/Admin/verification/<int:req_id>/document/<field>')
@admin_required
def verification_document(req_id,field):
    allowed={'face_photo':'Face photograph','nin_photo':'NIN document','cac_photo':'CAC document'}
    if field not in allowed: abort(404)
    c=db(); req=c.execute('SELECT * FROM verification_requests WHERE id=?',(req_id,)).fetchone(); c.close()
    if not req or not req[field]: abort(404)
    path=verification_document_path(req[field])
    if not path: abort(404)
    return send_file(path,mimetype=mimetypes.guess_type(path.name)[0] or 'application/octet-stream',conditional=True)

@app.post('/Admin/fraud/<int:report_id>/block')
@admin_required
def admin_block_fraudster(report_id):
    c=db()
    report=c.execute('SELECT user_id FROM fraud_reports WHERE id=?',(report_id,)).fetchone()
    if not report:
        c.close(); flash('Fraud report not found.','error'); return redirect(url_for('admin'))
    reason=str(request.form.get('block_reason') or 'Blocked after image fraud review.').strip()[:500]
    c.execute("UPDATE users SET is_blocked=1,blocked_at=CURRENT_TIMESTAMP,block_reason=?,is_verified=0 WHERE id=?",(reason,report['user_id']))
    c.execute("UPDATE properties SET published_to_propkonet=0 WHERE user_id=?",(report['user_id'],))
    c.execute("UPDATE fraud_reports SET status='blocked',reviewed_at=CURRENT_TIMESTAMP WHERE id=?",(report_id,))
    c.commit(); c.close()
    flash('Offender account blocked and PropkoNet listings removed.','error')
    return redirect(url_for('admin'))

@app.post('/Admin/fraud/<int:report_id>/dismiss')
@admin_required
def admin_dismiss_fraud(report_id):
    c=db()
    cur=c.execute("UPDATE fraud_reports SET status='dismissed',reviewed_at=CURRENT_TIMESTAMP WHERE id=?",(report_id,))
    c.commit(); c.close()
    if cur.rowcount: flash('Fraud report dismissed.','info')
    return redirect(url_for('admin'))

@app.post('/Admin/logout')
def admin_logout():
    # Drop the admin marker and expire the JWT cookie so the browser stops
    # attaching it on subsequent /Admin/* requests.
    session.pop('admin_authenticated',None)
    response=redirect(url_for('admin'))
    response.delete_cookie(ADMIN_COOKIE_NAME, path='/', httponly=True, samesite='Lax', secure=ADMIN_COOKIE_SECURE)
    return response

@app.route('/predict',methods=['GET','POST'])
@login_required
def predict():
    result=None; error=None
    if request.method=='POST':
        using_yardcode=request.form.get('location_method')=='yardcode'
        location_value=request.form.get('yardcode','').strip() if using_yardcode else request.form.get('city','').strip()
        required=['yardcode','property_type','bedrooms','bathrooms','area','age','parking'] if using_yardcode else ['state','city','property_type','bedrooms','bathrooms','area','age','parking']
        if any(not request.form.get(k) for k in required):
            error='Sorry you have to fill the required information for accurate result'
        else:
            try:
                if using_yardcode:
                    code=location_value.lower()
                    state=next((s for s in STATES if s.lower() in code),DATA['State'].mode().iloc[0])
                    city=next((c for c in CITIES if c.lower() in code),DATA.loc[DATA['State'].eq(state),'City'].mode().iloc[0])
                else:
                    state=request.form['state']; city=request.form['city']
                row=pd.DataFrame([{'State':state,'City':city,'Property_Type':{'Terraced Duplex':'Terrace Duplex'}.get(request.form['property_type'],request.form['property_type']),'Bedrooms':int(request.form['bedrooms']),'Bathrooms':int(request.form['bathrooms']),'Area_sqm':float(request.form['area']),'Age_Years':float(request.form['age']),'Parking_Spaces':int(request.form['parking'])}])
                price=float(MODEL.predict(row)[0]); price=enforce_lagos_large_home_floor(price, row.iloc[0]['Bedrooms'], state, city); low=price*.88; high=price*1.12
                result={'price':price,'low':low,'high':high,'model_confidence':MODEL_CONFIDENCE,'summary':row.iloc[0].to_dict(),'yardcode':location_value if using_yardcode else None,'location':f'{city}, {state}'}
            except Exception: error='Could not calculate this estimate. Please check the form values.'
    return render_template('predict.html',states=STATES,property_types=PROPERTY_TYPES,cities=CITIES,result=result,error=error)

@app.route('/image-predict',methods=['GET','POST'])
@login_required
def image_predict(): return redirect(url_for('predict') + '#image-predict-section')


def market_reference_estimate(data):
    # Compare visual details with the bundled Nigerian listing reference set.
    frame=DATA.copy()
    property_type=data.get('property_type')
    if property_type:
        aliases={'Terraced Duplex':'Terrace Duplex'}
        typed=frame[frame['Property_Type'].eq(aliases.get(property_type,property_type))]
        if len(typed) >= 5: frame=typed
    location=str(data.get('location_hint') or '').lower()
    if location:
        located=frame[frame.apply(lambda r: location in f"{r['City']} {r['State']}".lower(),axis=1)]
        if len(located) >= 5: frame=located
    median=float(frame['Price_NGN'].median())
    model_price=None
    bedrooms=data.get('bedrooms_guess'); bathrooms=data.get('bathrooms_guess')
    if bedrooms is not None and bathrooms is not None:
        try:
            city=next((c for c in CITIES if c.lower() in location),CITIES[0])
            state=next((s for s in STATES if s.lower() in location),DATA.iloc[0]['State'])
            ptype=property_type or frame['Property_Type'].mode().iloc[0]
            row=pd.DataFrame([{'State':state,'City':city,'Property_Type':{'Terraced Duplex':'Terrace Duplex'}.get(ptype,ptype),'Bedrooms':max(1,int(bedrooms)),'Bathrooms':max(1,int(bathrooms)),'Area_sqm':float(frame['Area_sqm'].median()),'Age_Years':float(frame['Age_Years'].median()),'Parking_Spaces':float(frame['Parking_Spaces'].median())}])
            model_price=float(MODEL.predict(row)[0])
        except (TypeError,ValueError,IndexError):
            model_price=None
    price=(model_price*.6+median*.4) if model_price else median
    spread=.15 if len(frame) >= 10 else .20
    return round(price),round(price*(1-spread)),round(price*(1+spread)),len(frame)

@app.post('/api/analyze-property-image')
@login_required
def analyze_property_image():
    files=request.files.getlist('images') or request.files.getlist('image')
    if not files or len(files)>MAX_IMAGE_COUNT:
        return jsonify({'error':f'Upload between 1 and {MAX_IMAGE_COUNT} images.'}),400
    for f in files:
        if not f or f.mimetype not in ALLOWED_IMAGE_MIMES:
            return jsonify({'error':'Upload JPEG, PNG, WEBP or GIF images only.'}),400
        raw=f.read()
        if len(raw)>MAX_IMAGE_BYTES:
            return jsonify({'error':'Each image must be 8 MB or smaller.'}),400
    analysis=normalize_visual_analysis({})
    location_hint=request.form.get('location_hint','').strip()
    price, low, high, matches = market_reference_estimate({**analysis,'location_hint':location_hint})
    features=', '.join(str(x) for x in analysis.get('amenities',[])[:4])
    query=' '.join(str(x) for x in [analysis.get('property_type') or 'property', location_hint, features, 'Nigeria'] if x)
    listing_searches=[
        {'site':'PropertyPro Nigeria','url':'https://www.google.com/search?q='+urllib.parse.quote('site:propertypro.ng '+query)},
        {'site':'Nigeria Property Centre','url':'https://www.google.com/search?q='+urllib.parse.quote('site:nigeriapropertycentre.com '+query)},
        {'site':'Jiji Nigeria','url':'https://www.google.com/search?q='+urllib.parse.quote('site:jiji.ng '+query)}]
    online_matches, online_search_message=online_listing_matches('('+query+') (site:propertypro.ng OR site:nigeriapropertycentre.com OR site:jiji.ng)')
    return jsonify({**analysis,'price':price,'low':low,'high':high,'market_matches':matches,'listing_searches':listing_searches,'online_matches':online_matches,'online_search_message':online_search_message})

@app.post('/api/image-analyze')
@login_required
def image_analyze():
    # Backward-compatible alias for the existing page while clients migrate.
    return analyze_property_image()

@app.post('/api/predict')
@login_required
def api_predict():
    try:
        payload=request.get_json(force=True); price,summary,visual=predict_from_payload(payload)
        return jsonify({'price':price,'low':price*.88,'high':price*1.12,'summary':summary,'visual_features':visual})
    except (TypeError,ValueError,KeyError):
        return jsonify({'error':'Invalid property prediction data.'}),400

SAMPLE_LISTINGS = [
    {'name': '5 Bedroom Detached Duplex in Lekki Phase 1 with BQ', 'location': 'Lekki, Lagos', 'price': 155_000_000, 'ai_price': 148_500_000, 'beds': 5, 'baths': 6, 'sqft': 4200, 'buyable': True, 'listing_type': 'sale'},
    {'name': 'Luxury 4 Bedroom Terraced Duplex, Ikoyi', 'location': 'Ikoyi, Lagos', 'price': 210_000_000, 'ai_price': 202_000_000, 'beds': 4, 'baths': 5, 'sqft': 3600, 'buyable': True, 'listing_type': 'sale'},
    {'name': 'Modern 3 Bedroom Flat in Gwarinpa', 'location': 'Gwarinpa, Abuja', 'price': 68_000_000, 'ai_price': 71_200_000, 'beds': 3, 'baths': 3, 'sqft': 1800, 'buyable': False, 'listing_type': 'sale'},
    {'name': 'Spacious 2 Bedroom Apartment, Ikeja GRA', 'location': 'Ikeja, Lagos', 'price': 42_500_000, 'ai_price': 39_800_000, 'beds': 2, 'baths': 2, 'sqft': 1200, 'buyable': False, 'listing_type': 'sale'},
    {'name': 'Executive 4 Bedroom Semi-Detached Duplex, Gwarinpa', 'location': 'Gwarinpa, Abuja', 'price': 95_000_000, 'ai_price': 92_400_000, 'beds': 4, 'baths': 4, 'sqft': 2900, 'buyable': True, 'listing_type': 'sale'},
    {'name': 'Smart Home 5 Bedroom Duplex with Pool, Ajah', 'location': 'Ajah, Lagos', 'price': 120_000_000, 'ai_price': 114_300_000, 'beds': 5, 'baths': 5, 'sqft': 3400, 'buyable': True, 'listing_type': 'sale'},
    {'name': 'Cozy 1 Bedroom Service Apartment, Wuse 2', 'location': 'Wuse, Abuja', 'price': 25_000_000, 'ai_price': 27_600_000, 'beds': 1, 'baths': 1, 'sqft': 700, 'buyable': False, 'listing_type': 'sale'},
    {'name': 'Newly Built 3 Bedroom Bungalow, Maitama Extension', 'location': 'Maitama, Abuja', 'price': 165_000_000, 'ai_price': 158_900_000, 'beds': 3, 'baths': 4, 'sqft': 2200, 'buyable': True, 'listing_type': 'sale'},
]

# Rentals shown on the PropkoNet "Rent" tab (annual rent in NGN).
RENT_LISTINGS = [
    {'name': 'Furnished 3 Bedroom Flat for Rent, Lekki Phase 1', 'location': 'Lekki, Lagos', 'price': 4_500_000, 'ai_price': 4_300_000, 'beds': 3, 'baths': 3, 'sqft': 1600, 'buyable': False, 'listing_type': 'rent'},
    {'name': 'Serviced 2 Bedroom Apartment for Rent, Ikoyi', 'location': 'Ikoyi, Lagos', 'price': 8_000_000, 'ai_price': 7_600_000, 'beds': 2, 'baths': 3, 'sqft': 1200, 'buyable': False, 'listing_type': 'rent'},
    {'name': 'Modern 4 Bedroom Duplex for Rent, Gwarinpa', 'location': 'Gwarinpa, Abuja', 'price': 6_500_000, 'ai_price': 6_100_000, 'beds': 4, 'baths': 4, 'sqft': 2600, 'buyable': False, 'listing_type': 'rent'},
    {'name': 'Cozy Studio Apartment for Rent, Wuse 2', 'location': 'Wuse, Abuja', 'price': 2_200_000, 'ai_price': 2_400_000, 'beds': 1, 'baths': 1, 'sqft': 650, 'buyable': False, 'listing_type': 'rent'},
    {'name': 'Newly Built 3 Bedroom Bungalow for Rent, Ajah', 'location': 'Ajah, Lagos', 'price': 3_600_000, 'ai_price': 3_400_000, 'beds': 3, 'baths': 3, 'sqft': 1900, 'buyable': False, 'listing_type': 'rent'},
]

@app.route('/propkonet')
def propkonet():
    c=db()
    db_props=c.execute('''
        SELECT p.*, u.email as seller_email, u.username as seller_username, u.phone as seller_phone
        FROM properties p
        JOIN users u ON p.user_id = u.id
        WHERE p.published_to_propkonet = 1 AND u.is_verified = 1
        ORDER BY p.id DESC
    ''').fetchall()
    c.close()

    verified_listings = []
    for p in db_props:
        p_dict = dict(p)
        price_val = float(p_dict.get('price') or 0)
        ai_price = p_dict.get('ai_price')
        if not ai_price or float(ai_price) <= 0:
            ai_price = round(price_val * 0.96)
        photo_filename = p_dict.get('photo')
        photo_url = url_for('static', filename=f'uploads/{photo_filename}') if photo_filename else None

        verified_listings.append({
            'id': p_dict['id'],
            'name': p_dict.get('name', 'Nigerian Property'),
            'location': p_dict.get('location', 'Nigeria'),
            'price': price_val,
            'ai_price': float(ai_price),
            'beds': int(p_dict.get('beds') or 3),
            'baths': int(p_dict.get('baths') or 3),
            'sqft': int(p_dict.get('sqft') or 1800),
            'photo': photo_filename,
            'photo_url': photo_url,
            'buyable': True,
            'is_verified_seller': True,
            'listing_type': (p_dict.get('listing_type') or 'sale'),
            'seller_name': p_dict.get('seller_username') or (p_dict.get('seller_email', '').split('@')[0]),
            'seller_email': p_dict.get('seller_email', ''),
            'seller_phone': p_dict.get('seller_phone') or 'Available on request'
        })

    # Combined listings: published properties from verified sellers first, then sample listings
    all_listings = verified_listings + SAMPLE_LISTINGS + RENT_LISTINGS
    return render_template('propkonet.html', listings=all_listings, states=STATES, property_types=PROPERTY_TYPES)

@app.route('/about')
@login_required
def about(): return render_template('about.html')

@app.route('/property-manager')
@owner_required
def property_manager():
    c=db()
    user_id=session['user_id']
    user=c.execute('SELECT * FROM users WHERE id=?',(user_id,)).fetchone()
    verification=c.execute('SELECT * FROM verification_requests WHERE user_id=? ORDER BY id DESC LIMIT 1',(user_id,)).fetchone()
    is_verified=bool(user['is_verified']) if (user and 'is_verified' in user.keys() and user['is_verified']) else False
    props=c.execute('SELECT * FROM properties WHERE user_id=? ORDER BY id DESC',(user_id,)).fetchall()
    tasks=c.execute('SELECT * FROM tasks WHERE user_id=? ORDER BY done,due',(user_id,)).fetchall()
    sales=c.execute('''SELECT t.*,p.name AS property_name FROM property_transactions t
        JOIN properties p ON p.id=t.property_id WHERE t.seller_id=? ORDER BY t.id DESC''',(user_id,)).fetchall()
    active=c.execute("SELECT COUNT(*) FROM properties WHERE user_id=? AND status != 'Closed'",(user_id,)).fetchone()[0]
    pipeline=c.execute("SELECT COALESCE(SUM(price),0) FROM properties WHERE user_id=? AND status != 'Closed'",(user_id,)).fetchone()[0]
    inquiries=c.execute("SELECT COUNT(*) FROM properties WHERE user_id=? AND status='Inquiry'",(user_id,)).fetchone()[0]
    month=c.execute("SELECT COALESCE(SUM(price),0) FROM properties WHERE user_id=? AND created_at >= datetime('now','start of month')",(user_id,)).fetchone()[0]
    c.close()
    return render_template('manager.html',props=props,tasks=tasks,sales=sales,kpis={'active':active,'pipeline':pipeline,'inquiries':inquiries,'month':month},user=user,verification=verification,is_verified=is_verified)

@app.post('/api/manager-ai')
@owner_required
def manager_ai():
    data=request.get_json(force=True) or {}; task=str(data.get('task','')).strip(); details=str(data.get('details','')).strip()
    if not task: return jsonify({'error':'Choose a document type.'}),400
    c=db(); template=c.execute('SELECT title,body FROM document_templates WHERE task=?',(task,)).fetchone(); c.close()
    if not template: return jsonify({'error':'That document template is not available.'}),404
    safe_details=details or '[Add the property, tenant, amount and date details here]'
    text=template['body'].replace('{{details}}',safe_details)
    return jsonify({'text':text,'title':template['title'],'source':'local template'})
    if False:
        fallback={'rent_notice':f'''RENT NOTICE\n\nDear Tenant,\n\nThis is a formal notice regarding the rent for {details or 'the property'}. Please review your tenancy records and make the required payment by the agreed due date.\n\nThank you,\nESTIMATE Property Management''','listing':f'''PROPERTY LISTING\n\nPresenting {details or 'a premium Nigerian property'} — a well-positioned opportunity for discerning buyers or tenants. Contact the property manager for pricing, inspection and documentation.''','followup':f'''FOLLOW-UP MESSAGE\n\nHello, I am following up regarding {details or 'the property enquiry'}. Please let me know a convenient time to continue the conversation or schedule an inspection.\n\nBest regards,\nESTIMATE Property Management''','management_agreement':f'''PROPERTY MANAGEMENT AGREEMENT\n\nParties: [Owner] and ESTIMATE Property Management\nProperty: {details or 'the property'}\nScope, fees, owner responsibilities and manager responsibilities: [Complete details].\nHave a qualified professional review before signing.''','lease_agreement':f'''RESIDENTIAL OR COMMERCIAL LEASE AGREEMENT\n\nProperty: {details or 'the property'}\nInclude rent, duration, permitted use, maintenance, utilities, default and termination terms. Have a qualified professional review before signing.''','rental_application':f'''RENTAL APPLICATION FORM\n\nApplicant details, employment, income, references, rental history and consent for lawful screening. Property: {details or 'the property'}.''','rent_ledger':f'''RENT LEDGER\n\nTenant/property: {details or 'the tenancy'}\nDate | Description | Due | Paid | Balance | Reference\nKeep entries chronological with supporting records.''','rent_receipt':f'''RENT RECEIPT\n\nReceived from: [Tenant]\nAmount: [Amount]\nFor: {details or 'rent'}\nPayment method: [Cash/Transfer/Check] | Date: [Date]\nCheck against the payment record.''','eviction_notice':f'''NOTICE TO QUIT / EVICTION NOTICE\n\nTenant/property: {details or 'the tenancy'}\nState the breach, required action and applicable dates only after qualified local legal review. This draft is not legal advice.'''}
        return jsonify({'text':fallback.get(task,'Please configure OPENAI_API_KEY for AI generation.')})
    try:
        client=OpenAI(api_key=api)
        prompt=f'''You are a professional Nigerian real-estate property manager. Generate a polished, practical document for this task: {task}. Property/client details: {details}. Keep it legally cautious, professional and editable. Do not invent laws or legal deadlines. Return plain text only.'''
        r=client.responses.create(model=os.getenv('OPENAI_TEXT_MODEL','gpt-5.4-mini'),input=prompt)
        return jsonify({'text':r.output_text})
    except Exception as e:
        app.logger.exception('OpenAI document generation failed')
        return jsonify({'error':openai_failure_message(e,'document generation')}),502

@app.post('/api/estimate-to-workspace')
@owner_required
def estimate_to_workspace():
    data=request.get_json(force=True) or {}
    try:
        price=float(data.get('price'))
        if not math.isfinite(price) or price < 0: raise ValueError
    except (TypeError,ValueError):
        return jsonify({'error':'Enter a valid estimate price.'}),400
    name=str(data.get('name') or 'AI Estimated Property').strip()[:120]
    location=str(data.get('location') or 'Nigeria').strip()[:160]
    status=str(data.get('status') or 'Inquiry')
    if status not in {'Inquiry','Viewing','Offer','Closed'}: status='Inquiry'
    c=db(); cur=c.execute('INSERT INTO properties(user_id,name,location,price,status,thumb) VALUES(?,?,?,?,?,?)',(session['user_id'],name,location,price,status,'house')); c.commit(); c.close()
    return jsonify({'ok':True,'property_id':cur.lastrowid})

@app.post('/api/request-verification')
@owner_required
def request_verification():
    d=request.get_json(silent=True) or request.form
    username=str(d.get('username','')).strip()
    phone=str(d.get('phone','')).strip()
    if not username or not phone:
        return jsonify({'error':'Username and phone number are required.'}), 400
    user_id=session['user_id']
    email=session.get('email','')
    c=db()
    c.execute('UPDATE users SET username=?, phone=? WHERE id=?', (username, phone, user_id))
    pending=c.execute("SELECT id FROM verification_requests WHERE user_id=? AND status='pending'", (user_id,)).fetchone()
    if pending:
        c.execute("UPDATE verification_requests SET username=?, phone=?, updated_at=CURRENT_TIMESTAMP WHERE id=?", (username, phone, pending['id']))
    else:
        c.execute("INSERT INTO verification_requests(user_id, email, username, phone, status) VALUES(?,?,?,?,'pending')", (user_id, email, username, phone))
    c.commit(); c.close()
    return jsonify({'ok': True, 'message': 'Verification request submitted! Admin has received your details.'})

@app.route('/verification/start')
@owner_required
def verification_start():
    c=db()
    user=c.execute('SELECT * FROM users WHERE id=?',(session['user_id'],)).fetchone()
    verification=c.execute('SELECT * FROM verification_requests WHERE user_id=? ORDER BY id DESC LIMIT 1',(session['user_id'],)).fetchone()
    c.close()
    return render_template('verification.html',user=user,verification=verification)

@app.post('/api/verification/submit')
@owner_required
def submit_verification():
    fields={
        'username':str(request.form.get('username','')).strip(),
        'phone':str(request.form.get('phone','')).strip(),
        'business_address':str(request.form.get('business_address','')).strip(),
        'nin_number':str(request.form.get('nin_number','')).strip(),
        'cac_number':str(request.form.get('cac_number','')).strip()
    }
    if not fields['username'] or not fields['phone'] or not fields['business_address'] or not fields['nin_number'] or not fields['cac_number']:
        return jsonify({'error':'Complete all business and identity details before submitting.'}),400
    uploads={}
    saved=[]
    for field in ['face_photo','nin_photo','cac_photo']:
        raw,error=validate_verification_upload(request.files.get(field),field.replace('_',' ').title())
        if error:
            cleanup_verification_uploads(saved)
            return jsonify({'error':error}),400
        ext=request.files[field].filename.rsplit('.',1)[-1].lower()
        filename=save_verification_upload(raw,ext)
        saved.append(filename); uploads[field]=filename
    c=db()
    try:
        existing=c.execute("SELECT * FROM verification_requests WHERE user_id=? AND status IN ('pending','rejected') ORDER BY id DESC LIMIT 1",(session['user_id'],)).fetchone()
        approved=c.execute("SELECT id FROM verification_requests WHERE user_id=? AND status='approved' ORDER BY id DESC LIMIT 1",(session['user_id'],)).fetchone()
        if approved:
            cleanup_verification_uploads(saved); c.close(); return jsonify({'error':'This account has already been verified.'}),409
        old_files=[]
        if existing and existing['status']=='pending':
            old_files=[existing['face_photo'],existing['nin_photo'],existing['cac_photo']]
            c.execute('''UPDATE verification_requests SET email=?,username=?,phone=?,business_address=?,nin_number=?,cac_number=?,face_photo=?,nin_photo=?,cac_photo=?,updated_at=CURRENT_TIMESTAMP WHERE id=?''',(session.get('email',''),fields['username'],fields['phone'],fields['business_address'],fields['nin_number'],fields['cac_number'],uploads['face_photo'],uploads['nin_photo'],uploads['cac_photo'],existing['id']))
            request_id=existing['id']
        else:
            cur=c.execute('''INSERT INTO verification_requests(user_id,email,username,phone,business_address,nin_number,cac_number,face_photo,nin_photo,cac_photo,status) VALUES(?,?,?,?,?,?,?,?,?,?, 'pending')''',(session['user_id'],session.get('email',''),fields['username'],fields['phone'],fields['business_address'],fields['nin_number'],fields['cac_number'],uploads['face_photo'],uploads['nin_photo'],uploads['cac_photo']))
            request_id=cur.lastrowid
        c.execute('UPDATE users SET username=?,phone=? WHERE id=?',(fields['username'],fields['phone'],session['user_id']))
        c.commit()
    except Exception:
        c.rollback(); cleanup_verification_uploads(saved); c.close(); raise
    cleanup_verification_uploads(old_files)
    c.close()
    return jsonify({'ok':True,'message':'Verification documents submitted for admin review.','verification_id':request_id})

@app.post('/api/property')
@owner_required
def add_property():
    d=request.form
    try:
        price=float(d.get('price',''))
        if not math.isfinite(price) or price < 0:
            raise ValueError
    except (TypeError, ValueError):
        return jsonify({'error':'Enter a valid, non-negative property price.'}),400
    photos=request.files.getlist('photo'); photo_name=None; photo_names=[]
    allowed={'jpg','jpeg','png','webp','gif'}
    for photo in photos:
        if not photo or not photo.filename: continue
        ext=photo.filename.rsplit('.',1)[-1].lower() if '.' in photo.filename else ''
        if ext not in allowed: return jsonify({'error':'Upload JPG, PNG, WEBP or GIF images.'}),400
        name=f'{uuid4().hex}.{ext}'; photo.save(UPLOADS/name); photo_names.append(name)
    photo_name=photo_names[0] if photo_names else None

    c=db()
    user=c.execute('SELECT is_verified FROM users WHERE id=?', (session['user_id'],)).fetchone()
    is_verified=bool(user['is_verified']) if user else False

    # Check publish flag - only verified sellers can publish to propkonet
    publish_flag = 1 if (is_verified and str(d.get('publish_to_propkonet','')).lower() in ('1','true','on','yes')) else 0
    beds = max(1, int(d.get('beds', 3))) if d.get('beds') else 3
    baths = max(1, int(d.get('baths', 3))) if d.get('baths') else 3
    sqft = max(10, float(d.get('sqft', 1800))) if d.get('sqft') else 1800
    prop_type = d.get('property_type', 'Detached Duplex')
    listing_type = 'rent' if str(d.get('listing_type','')).strip().lower() == 'rent' else 'sale'
    ai_price = round(price * 0.96)

    cur=c.execute('''
        INSERT INTO properties(user_id,name,location,price,status,thumb,photo,published_to_propkonet,beds,baths,sqft,property_type,ai_price,listing_type)
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)
    ''',(session['user_id'],d.get('name','New Property'),d.get('location','Nigeria'),price,d.get('status','Inquiry'),'house',photo_name,publish_flag,beds,baths,sqft,prop_type,ai_price,listing_type))
    property_id=cur.lastrowid
    c.executemany('INSERT INTO property_photos(property_id,filename) VALUES(?,?)',[(property_id,name) for name in photo_names]); c.commit(); c.close(); return jsonify({'ok':True})

@app.post('/api/property/<int:property_id>/edit')
@owner_required
def edit_property(property_id):
    d=request.form
    try:
        price=float(d.get('price',''))
        if not math.isfinite(price) or price < 0: raise ValueError
    except (TypeError, ValueError): return jsonify({'error':'Enter a valid, non-negative property price.'}),400
    c=db(); prop=c.execute('SELECT * FROM properties WHERE id=? AND user_id=?',(property_id,session['user_id'])).fetchone()
    if not prop: c.close(); return jsonify({'error':'Property not found.'}),404

    user=c.execute('SELECT is_verified FROM users WHERE id=?', (session['user_id'],)).fetchone()
    is_verified=bool(user['is_verified']) if user else False

    if is_verified and 'publish_to_propkonet' in d:
        publish_flag = 1 if str(d.get('publish_to_propkonet','')).lower() in ('1','true','on','yes') else 0
    elif not is_verified:
        publish_flag = 0
    else:
        publish_flag = prop['published_to_propkonet'] if 'published_to_propkonet' in prop.keys() and prop['published_to_propkonet'] else 0

    beds = max(1, int(d.get('beds', prop['beds'] if 'beds' in prop.keys() and prop['beds'] else 3)))
    baths = max(1, int(d.get('baths', prop['baths'] if 'baths' in prop.keys() and prop['baths'] else 3)))
    sqft = max(10, float(d.get('sqft', prop['sqft'] if 'sqft' in prop.keys() and prop['sqft'] else 1800)))
    prop_type = d.get('property_type', prop['property_type'] if 'property_type' in prop.keys() and prop['property_type'] else 'Detached Duplex')
    if 'listing_type' in d:
        listing_type = 'rent' if str(d.get('listing_type','')).strip().lower() == 'rent' else 'sale'
    else:
        listing_type = prop['listing_type'] if 'listing_type' in prop.keys() and prop['listing_type'] else 'sale'
    ai_price = round(price * 0.96)

    c.execute('''
        UPDATE properties SET name=?,location=?,price=?,status=?,published_to_propkonet=?,beds=?,baths=?,sqft=?,property_type=?,ai_price=?,listing_type=?
        WHERE id=? AND user_id=?
    ''',(d.get('name','New Property'),d.get('location','Nigeria'),price,d.get('status','Inquiry'),publish_flag,beds,baths,sqft,prop_type,ai_price,listing_type,property_id,session['user_id']))
    photos=request.files.getlist('photo'); allowed={'jpg','jpeg','png','webp','gif'}; names=[]
    for photo in photos:
        if not photo or not photo.filename: continue
        ext=photo.filename.rsplit('.',1)[-1].lower() if '.' in photo.filename else ''
        if ext not in allowed: c.close(); return jsonify({'error':'Upload JPG, PNG, WEBP or GIF images.'}),400
        name=f'{uuid4().hex}.{ext}'; photo.save(UPLOADS/name); names.append(name)
    if names:
        c.execute('UPDATE properties SET photo=? WHERE id=?',(names[0],property_id)); c.executemany('INSERT INTO property_photos(property_id,filename) VALUES(?,?)',[(property_id,name) for name in names])
    c.commit(); c.close(); return jsonify({'ok':True})

@app.post('/api/property/<int:property_id>/toggle-propkonet')
@owner_required
def toggle_propkonet(property_id):
    c=db()
    user=c.execute('SELECT is_verified FROM users WHERE id=?', (session['user_id'],)).fetchone()
    if not user or not user['is_verified']:
        c.close()
        return jsonify({'error':'You must be a verified seller before you can publish properties to PropkoNet. Please click "Get verified to sell property".'}), 403
    prop=c.execute('SELECT * FROM properties WHERE id=? AND user_id=?', (property_id, session['user_id'])).fetchone()
    if not prop:
        c.close(); return jsonify({'error':'Property not found.'}), 404
    cur_val=prop['published_to_propkonet'] if 'published_to_propkonet' in prop.keys() and prop['published_to_propkonet'] else 0
    new_val=0 if cur_val else 1
    ai_price=prop['ai_price'] if 'ai_price' in prop.keys() and prop['ai_price'] else round(prop['price'] * 0.96)
    c.execute('UPDATE properties SET published_to_propkonet=?, ai_price=? WHERE id=? AND user_id=?', (new_val, ai_price, property_id, session['user_id']))
    c.commit(); c.close()
    return jsonify({
        'ok': True,
        'published': bool(new_val),
        'message': 'Property is now live on PropkoNet for buyers!' if new_val else 'Property was removed from PropkoNet.'
    })

@app.post('/api/propkonet/buy')
def propkonet_buy():
    d=request.get_json(silent=True) or request.form
    buyer_name=str(d.get('name','')).strip()
    buyer_email=str(d.get('email','')).strip()
    buyer_phone=str(d.get('phone','')).strip()
    message=str(d.get('message','')).strip()
    property_id=d.get('property_id')
    try:
        property_id=int(property_id) if property_id else None
    except (TypeError, ValueError):
        property_id=None

    if not buyer_name or not buyer_email or not buyer_phone:
        return jsonify({'error':'Your name, email and phone number are required for secure checkout.'}), 400
    if not property_id:
        return jsonify({'error':'This listing is an enquiry-only listing and cannot be checked out online.'}), 400
    c=db(); prop=c.execute('''SELECT p.id,p.name,p.price,p.user_id,u.is_verified
        FROM properties p JOIN users u ON u.id=p.user_id
        WHERE p.id=? AND p.published_to_propkonet=1''',(property_id,)).fetchone()
    if not prop or not prop['is_verified'] or not prop['price'] or float(prop['price']) <= 0:
        c.close(); return jsonify({'error':'This property is not currently available for secure checkout.'}), 404
    amount_kobo=round(float(prop['price'])*100)
    reference='HOUSE-'+uuid4().hex
    buyer_token=uuid4().hex
    c.execute('''INSERT INTO property_transactions(property_id,seller_id,buyer_name,buyer_email,buyer_phone,amount_kobo,reference,buyer_token)
        VALUES(?,?,?,?,?,?,?,?,?)''',(prop['id'],prop['user_id'],buyer_name,buyer_email,buyer_phone,amount_kobo,reference,buyer_token))
    # Retain the buyer's optional message as an audit-friendly purchase inquiry.
    c.execute('''INSERT INTO property_purchases(property_id,buyer_name,buyer_email,buyer_phone,offer_price,message,status)
        VALUES(?,?,?,?,?,?,?)''',(prop['id'],buyer_name,buyer_email,buyer_phone,float(prop['price']),message,'checkout_started'))
    c.commit(); c.close()
    try:
        checkout=paystack_request('/transaction/initialize','POST',{
            'email':buyer_email,'amount':str(amount_kobo),'currency':'NGN','reference':reference,
            'callback_url':payment_callback_url(reference,buyer_token),
            'metadata':json.dumps({'property_id':prop['id'],'property_name':prop['name'],'purchase_reference':reference})
        })
    except RuntimeError as exc:
        c=db(); c.execute("UPDATE property_transactions SET status='payment_pending' WHERE reference=?",(reference,)); c.commit(); c.close()
        return jsonify({'error':str(exc)}),503
    return jsonify({'ok':True,'checkout_url':checkout['authorization_url']})

@app.get('/payments/callback/<reference>')
def payment_callback(reference):
    token=request.args.get('token','')
    c=db(); transaction=c.execute('SELECT buyer_token FROM property_transactions WHERE reference=?',(reference,)).fetchone(); c.close()
    if not transaction or not hmac.compare_digest(transaction['buyer_token'],token): abort(404)
    try:
        mark_transaction_paid(reference)
    except RuntimeError:
        pass # The webhook will retry; the status screen remains safe to refresh.
    return redirect(url_for('purchase_status', reference=reference, token=token))

@app.post('/webhooks/paystack')
def paystack_webhook():
    raw=request.get_data()
    signature=request.headers.get('x-paystack-signature','')
    expected=hmac.new(PAYSTACK_SECRET_KEY.encode('utf-8'),raw,sha256).hexdigest() if PAYSTACK_SECRET_KEY else ''
    if not expected or not hmac.compare_digest(signature,expected): abort(401)
    event=request.get_json(silent=True) or {}; data=event.get('data') or {}
    if event.get('event') == 'charge.success':
        try: mark_transaction_paid(str(data.get('reference','')))
        except RuntimeError: return '',500
    elif event.get('event') in ('transfer.success','transfer.failed','transfer.reversed'):
        ref=str(data.get('reference',''))
        c=db(); c.execute('UPDATE property_transactions SET transfer_status=? WHERE transfer_reference=?',(event['event'],ref)); c.commit(); c.close()
    return '',200

@app.get('/purchase/<reference>')
def purchase_status(reference):
    token=request.args.get('token','')
    c=db(); sale=c.execute('''SELECT t.*,p.name AS property_name,p.location FROM property_transactions t
        JOIN properties p ON p.id=t.property_id WHERE t.reference=?''',(reference,)).fetchone(); c.close()
    if not sale or not hmac.compare_digest(sale['buyer_token'],token): abort(404)
    return render_template('purchase_status.html', sale=sale, token=token)

@app.post('/api/purchases/<reference>/confirm-verification')
def confirm_property_verification(reference):
    d=request.get_json(silent=True) or request.form; token=str(d.get('token',''))
    c=db(); sale=c.execute('SELECT * FROM property_transactions WHERE reference=?',(reference,)).fetchone()
    if not sale or not hmac.compare_digest(sale['buyer_token'],token): c.close(); return jsonify({'error':'Purchase link is invalid.'}),404
    if sale['status'] != 'documents_ready': c.close(); return jsonify({'error':'The seller must mark the required documents as handed over first.'}),409
    release_at=(datetime.now(timezone.utc)+timedelta(hours=24)).strftime('%Y-%m-%d %H:%M:%S')
    c.execute("UPDATE property_transactions SET status='awaiting_release',buyer_confirmed_at=CURRENT_TIMESTAMP,release_at=? WHERE id=?",(release_at,sale['id']))
    add_seller_task(c,sale['seller_id'],f'Buyer confirmed property verification. Payout for sale {reference} is scheduled after 24 hours.','Payout scheduled')
    c.commit(); c.close()
    return jsonify({'ok':True,'message':'Verification confirmed. The seller payout is scheduled for 24 hours from now.'})

@app.post('/api/purchases/<int:transaction_id>/documents-ready')
@owner_required
def documents_ready(transaction_id):
    c=db(); sale=c.execute('SELECT * FROM property_transactions WHERE id=? AND seller_id=?',(transaction_id,session['user_id'])).fetchone()
    if not sale: c.close(); return jsonify({'error':'Sale not found.'}),404
    if sale['status'] != 'paid': c.close(); return jsonify({'error':'Documents can only be marked ready after a verified payment.'}),409
    c.execute("UPDATE property_transactions SET status='documents_ready',documents_ready_at=CURRENT_TIMESTAMP WHERE id=?",(transaction_id,))
    c.commit(); c.close(); return jsonify({'ok':True,'message':'Documents marked as handed over. The buyer can now confirm property verification.'})

@app.post('/api/seller/paystack-recipient')
@owner_required
def save_paystack_recipient():
    recipient=str((request.get_json(silent=True) or request.form).get('recipient_code','')).strip()
    if recipient and not re.fullmatch(r'RCP_[A-Za-z0-9]+', recipient):
        return jsonify({'error':'Enter a valid Paystack recipient code (for example, RCP_xxx).'}),400
    c=db(); c.execute('UPDATE users SET paystack_recipient_code=? WHERE id=?',(recipient or None,session['user_id'])); c.commit(); c.close()
    return jsonify({'ok':True,'message':'Paystack payout recipient saved.'})

@app.post('/internal/payments/release-due')
def release_due_payments():
    provided=request.headers.get('X-Release-Secret','')
    if not PAYSTACK_RELEASE_CRON_SECRET or not hmac.compare_digest(provided,PAYSTACK_RELEASE_CRON_SECRET): abort(401)
    return jsonify({'ok':True,'results':release_due_transactions()})

@app.delete('/api/property/<int:property_id>')
@owner_required
def delete_property(property_id):
    c=db()
    prop=c.execute('SELECT photo FROM properties WHERE id=? AND user_id=?',(property_id,session['user_id'])).fetchone()
    if not prop:
        c.close()
        return jsonify({'error':'Property not found.'}),404
    photos=[row['filename'] for row in c.execute('SELECT filename FROM property_photos WHERE property_id=?',(property_id,)).fetchall()]
    if prop['photo'] and prop['photo'] not in photos: photos.append(prop['photo'])
    c.execute('DELETE FROM property_photos WHERE property_id=?',(property_id,))
    c.execute('DELETE FROM properties WHERE id=? AND user_id=?',(property_id,session['user_id']))
    c.commit(); c.close()
    for filename in photos:
        try: (UPLOADS/filename).unlink(missing_ok=True)
        except OSError: pass
    return jsonify({'ok':True})

@app.get('/api/property/<int:property_id>/photos')
@owner_required
def property_photos(property_id):
    c=db(); prop=c.execute('SELECT id, name, location, price, status, photo FROM properties WHERE id=? AND user_id=?',(property_id,session['user_id'])).fetchone()
    if not prop: c.close(); return jsonify({'error':'Property not found.'}),404
    names=[row['filename'] for row in c.execute('SELECT filename FROM property_photos WHERE property_id=? ORDER BY id',(property_id,)).fetchall()]
    if prop['photo'] and prop['photo'] not in names: names.insert(0,prop['photo'])
    c.close(); return jsonify({'property':dict(prop),'photos':[url_for('static',filename='uploads/'+name) for name in names]})

@app.post('/api/task')
@owner_required
def add_task():
    d=request.get_json(force=True); title=d.get('title','').strip(); due=d.get('due','').strip()
    if not title: return jsonify({'error':'Enter a task title.'}),400
    c=db(); c.execute('INSERT INTO tasks(user_id,title,due) VALUES(?,?,?)',(session['user_id'],title,due or 'No due date')); c.commit(); c.close(); return jsonify({'ok':True})

@app.post('/api/task/<int:task_id>/toggle')
@owner_required
def toggle_task(task_id):
    c=db(); c.execute('UPDATE tasks SET done=CASE done WHEN 0 THEN 1 ELSE 0 END WHERE id=? AND user_id=?',(task_id,session['user_id'])); c.commit(); c.close(); return jsonify({'ok':True})

if __name__=='__main__': app.run(debug=True,host='127.0.0.1',port=5000)
