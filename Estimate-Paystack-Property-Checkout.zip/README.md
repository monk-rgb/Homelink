# ESTIMATE AI — Nigerian House Price Prediction Webapp

Full Flask webapp generated from the supplied 1,000-row Nigerian house-price dataset. The trained model is included as `model.joblib`.

## Features
- Gold/dark responsive UI using Fraunces + Outfit.
- Welcome, Form Predict, Image Predict, About, and Property Manager core pages.
- Signup/login with role selection: normal user or real-estate business owner.
- Owner-only Property Manager dashboard with KPIs, deal pipeline, properties, tasks and AI document generator.
- Form prediction uses the supplied dataset and trained CatBoost regression pipeline.
- Image prediction uses OpenAI vision through the Responses API.
- Camera capture uses browser `getUserMedia`.
- Required-field validation shows the requested message in the estimate area.

## Dataset
Columns used: State, City, Property_Type, Bedrooms, Bathrooms, Area_sqm, Age_Years, Parking_Spaces -> Price_NGN.
Training split: 80/20. Holdout R²: 0.8866; MAE: ₦11,151,719.

## Run
1. Install Python 3.10+
2. Create and activate a virtual environment.
3. `pip install -r requirements.txt`
4. Copy `.env.example` to `.env` and add your OpenAI API key. Add a SerpAPI key as `SERPAPI_KEY` to fetch online listing results and prices; without it, the page still provides the local estimate and manual search links.
5. Run `python app.py`
6. Open http://127.0.0.1:5000

## Important
The dataset contains 37 state labels including the Federal Capital Territory. The requested nine property title types are supported in the UI; the trained model has learned from the five property types actually present in the supplied dataset. For unsupported form property types, the pipeline's one-hot encoder handles them as unseen categories, so those predictions should be treated cautiously.

For production: use HTTPS, a production WSGI server, a strong secret key, CSRF protection, rate limiting, persistent database hosting, object storage for uploads, and proper legal/privacy controls.

## Paystack property checkout

The PropkoNet **Buy Now** flow now creates a Paystack-hosted checkout on the server. The amount is always read from the live listing, so the browser cannot alter the sale price. A completed charge is verified with Paystack before the seller receives an in-app task to hand over documents. The buyer's private status link lets them confirm property verification; this schedules a seller transfer after 24 hours.

Before using it outside development:

1. Add `PAYSTACK_SECRET_KEY`, `PAYSTACK_CALLBACK_BASE_URL` (the public HTTPS address of this app), and `PAYSTACK_RELEASE_CRON_SECRET` to `.env`.
2. In the Paystack dashboard, set the webhook URL to `https://your-domain/webhooks/paystack` so successful charges and final transfer status events are received.
3. Each seller must save their Paystack transfer recipient code (`RCP_...`) in Property Manager before a payout can be released.
4. Configure a trusted hourly scheduler to POST to `/internal/payments/release-due` with header `X-Release-Secret: <PAYSTACK_RELEASE_CRON_SECRET>`. This endpoint initiates due transfers and is deliberately protected from public access.

Use Paystack test keys and test transactions first. Real-estate transactions can require licensing, escrow/custody arrangements, AML/KYC screening, dispute handling, and legal review in the relevant jurisdiction; confirm that this payout design is approved for your business before enabling live payments.
